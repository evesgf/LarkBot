// GUI Animator for Unity UI
// Version: 1.1.1
// Compatilble: Unity 5.4.0 or higher, more info in Readme.txt file.
//
// Developer:				Gold Experience Team (http://www.ge-team.com)
// Unity Asset Store:		https://www.assetstore.unity3d.com/en/#!/content/28709
// Gold Experience Store:	https://www.ge-team.com/en/products/gui-animator-for-unity-ui/
// Support:					geteamdev@gmail.com
//
// Please direct any bugs/comments/suggestions to geteamdev@gmail.com.

// ######################################################################
// Demo06_JS class
// - Animates all GAui elements in the scene.
// - Responds to user mouse click or tap on buttons.
//
// Note this class is attached with "-SceneController-" object in "GA UUI JS - Demo06 (960x600px)" scene.
// ######################################################################

class Demo06_JS extends MonoBehaviour {

	// ########################################
	// Variables
	// ########################################

    // Canvas
    var m_Canvas : Canvas;
	
   // GUIAnim objects of title text
    var m_Title1 : GAui;
    var m_Title2 : GAui;
	
   // GUIAnim objects of top and bottom bars
    var m_TopBar : GAui;
    var m_BottomBar : GAui;
	
   // GUIAnim objects of primary buttons
    var m_PrimaryButton1 : GAui;
    var m_PrimaryButton2 : GAui;
    var m_PrimaryButton3 : GAui;
    var m_PrimaryButton4 : GAui;
    var m_PrimaryButton5 : GAui;

   // GUIAnim objects of secondary buttons
    var m_SecondaryButton1 : GAui;
    var m_SecondaryButton2 : GAui;
    var m_SecondaryButton3 : GAui;
    var m_SecondaryButton4 : GAui;
    var m_SecondaryButton5 : GAui;
	
   // Toggle state of buttons
    protected var m_Button1_IsOn : boolean= false;
    protected var m_Button2_IsOn : boolean= false;
    protected var m_Button3_IsOn : boolean= false;
    protected var m_Button4_IsOn : boolean= false;
    protected var m_Button5_IsOn : boolean= false;

	// ########################################
	// MonoBehaviour Functions
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.html
	// ########################################
		
	// Awake is called when the script instance is being loaded.
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.Awake.html
   function Awake () {

       if(enabled)
       {
           // Set GSui.Instance.m_AutoAnimation to false in Awake(), let you control all GUI Animator elements in the scene via scripts.
			GSui.Instance.m_AutoAnimation = false;
       }
   }
	
	// Start is called on the frame when a script is enabled just before any of the Update methods is called the first time.
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.Start.html
        function Start () {
            // MoveIn m_TopBar and m_BottomBar
            m_TopBar.MoveIn(GSui.eGUIMove.SelfAndChildren);
            m_BottomBar.MoveIn(GSui.eGUIMove.SelfAndChildren);
		
            // MoveIn m_Title1 m_Title2
            StartCoroutine(MoveInTitleGameObjects());
		
            // Disable all scene switch buttons
		// http://docs.unity3d.com/Manual/script-GraphicRaycaster.html
            GSui.Instance.SetGraphicRaycasterEnable(m_Canvas, false);
        }
	
	// Update is called every frame, if the MonoBehaviour is enabled.
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.Update.html
        function Update () {
		
        }
	
	// ########################################
	// MoveIn/MoveOut functions
	// ########################################
	
        // Move In m_Title1 and m_Title2
        function MoveInTitleGameObjects () : IEnumerator {
            yield  WaitForSeconds(1.0f);
		
            // Move In m_Title1 and m_Title2
            m_Title1.MoveIn(GSui.eGUIMove.Self);
            m_Title2.MoveIn(GSui.eGUIMove.Self);
		
            // MoveIn dialogs
            StartCoroutine(MoveInPrimaryButtons());
		
            // Enable all scene switch buttons
		// http://docs.unity3d.com/Manual/script-GraphicRaycaster.html
            GSui.Instance.SetGraphicRaycasterEnable(m_Canvas, true);
        }
	
            // MoveIn all primary buttons
            function MoveInPrimaryButtons () : IEnumerator {
                yield  WaitForSeconds(1.0f);
		
                // MoveIn all primary buttons
                m_PrimaryButton1.MoveIn(GSui.eGUIMove.Self);	
                m_PrimaryButton2.MoveIn(GSui.eGUIMove.Self);	
                m_PrimaryButton3.MoveIn(GSui.eGUIMove.Self);	
                m_PrimaryButton4.MoveIn(GSui.eGUIMove.Self);

                m_PrimaryButton5.MoveIn(GSui.eGUIMove.Self);
		
                // Enable all scene switch buttons
                StartCoroutine(EnableAllDemoButtons());
            }
	
                // MoveOut all primary buttons
                function HideAllGUIs () {
                    // MoveOut all primary buttons
                    m_PrimaryButton1.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    m_PrimaryButton2.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    m_PrimaryButton3.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    m_PrimaryButton4.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    m_PrimaryButton5.MoveOut(GSui.eGUIMove.SelfAndChildren);
		
                    // MoveOut all secondary buttons
                    if(m_Button1_IsOn == true)
                        m_SecondaryButton1.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    if(m_Button2_IsOn == true)
                        m_SecondaryButton2.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    if(m_Button3_IsOn == true)
                        m_SecondaryButton3.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    if(m_Button4_IsOn == true)
                        m_SecondaryButton4.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    if(m_Button5_IsOn == true)
                        m_SecondaryButton5.MoveOut(GSui.eGUIMove.SelfAndChildren);
		
                    // MoveOut m_Title1 and m_Title2
                    StartCoroutine(HideTitleTextMeshes());
                }
	
                // MoveOut m_Title1 and m_Title2
                function HideTitleTextMeshes () : IEnumerator {
                    yield  WaitForSeconds(1.0f);
		
                    // MoveOut m_Title1 and m_Title2
                    m_Title1.MoveOut(GSui.eGUIMove.Self);
                    m_Title2.MoveOut(GSui.eGUIMove.Self);
		
                    // MoveOut m_TopBar and m_BottomBar
                    m_TopBar.MoveOut(GSui.eGUIMove.SelfAndChildren);
                    m_BottomBar.MoveOut(GSui.eGUIMove.SelfAndChildren);
                }
	
	// ########################################
	// Enable/Disable button functions
	// ########################################
	
                    // Enable/Disable all scene switch Coroutine
                    function EnableAllDemoButtons () : IEnumerator {
                        yield  WaitForSeconds(1.0f);
		
                        // Enable all scene switch buttons
		// http://docs.unity3d.com/Manual/script-GraphicRaycaster.html
                        GSui.Instance.SetGraphicRaycasterEnable(m_Canvas, true);
                    }

                        // Disable all buttons for a few seconds
                        function DisableAllButtonsForSeconds ( DisableTime : float  ) : IEnumerator {
                            // Disable all buttons
                            GSui.Instance.EnableAllButtons(false);
		
                            yield  WaitForSeconds(DisableTime);
		
                            // Enable all buttons
                            GSui.Instance.EnableAllButtons(true);
                        }
	
	// ########################################
	// UI Responder functions
	// ########################################
	
                            function OnButton_1 () {
                                // Disable all buttons for a few seconds
                                StartCoroutine(DisableAllButtonsForSeconds(0.6f));

                                // Toggle m_Button1
                                ToggleButton_1();
		
                                // Toggle other buttons
                                if(m_Button2_IsOn==true)
                                {
                                    ToggleButton_2();
                                }
                                if(m_Button3_IsOn==true)
                                {
                                    ToggleButton_3();
                                }
                                if(m_Button4_IsOn==true)
                                {
                                    ToggleButton_4();
                                }
                                if(m_Button5_IsOn==true)
                                {
                                    ToggleButton_5();
                                }
                            }
	
                            function OnButton_2 () {
                                // Disable all buttons for a few seconds
                                StartCoroutine(DisableAllButtonsForSeconds(0.6f));

                                // Toggle m_Button2
                                ToggleButton_2();
		
                                // Toggle other buttons
                                if(m_Button1_IsOn==true)
                                {
                                    ToggleButton_1();
                                }
                                if(m_Button3_IsOn==true)
                                {
                                    ToggleButton_3();
                                }
                                if(m_Button4_IsOn==true)
                                {
                                    ToggleButton_4();
                                }
                                if(m_Button5_IsOn==true)
                                {
                                    ToggleButton_5();
                                }
                            }
	
                            function OnButton_3 () {
                                // Disable all buttons for a few seconds
                                StartCoroutine(DisableAllButtonsForSeconds(0.6f));

                                // Toggle m_Button3
                                ToggleButton_3();
		
                                // Toggle other buttons
                                if(m_Button1_IsOn==true)
                                {
                                    ToggleButton_1();
                                }
                                if(m_Button2_IsOn==true)
                                {
                                    ToggleButton_2();
                                }
                                if(m_Button4_IsOn==true)
                                {
                                    ToggleButton_4();
                                }
                                if(m_Button5_IsOn==true)
                                {
                                    ToggleButton_5();
                                }
                            }
	
                            function OnButton_4 () {
                                // Disable all buttons for a few seconds
                                StartCoroutine(DisableAllButtonsForSeconds(0.6f));

                                // Toggle m_Button4
                                ToggleButton_4();
		
                                // Toggle other buttons
                                if(m_Button1_IsOn==true)
                                {
                                    ToggleButton_1();
                                }
                                if(m_Button2_IsOn==true)
                                {
                                    ToggleButton_2();
                                }
                                if(m_Button3_IsOn==true)
                                {
                                    ToggleButton_3();
                                }
                                if(m_Button5_IsOn==true)
                                {
                                    ToggleButton_5();
                                }
                            }
	
                            function OnButton_5 () {
                                // Disable all buttons for a few seconds
                                StartCoroutine(DisableAllButtonsForSeconds(0.6f));

                                // Toggle m_Button5
                                ToggleButton_5();
		
                                // Toggle other buttons
                                if(m_Button1_IsOn==true)
                                {
                                    ToggleButton_1();
                                }
                                if(m_Button2_IsOn==true)
                                {
                                    ToggleButton_2();
                                }
                                if(m_Button3_IsOn==true)
                                {
                                    ToggleButton_3();
                                }
                                if(m_Button4_IsOn==true)
                                {
                                    ToggleButton_4();
                                }
                            }
	
	// ########################################
	// Toggle button functions
	// ########################################
	
                            // Toggle m_Button1
                            function ToggleButton_1 () {
                                m_Button1_IsOn = !m_Button1_IsOn;
                                if(m_Button1_IsOn==true)
                                {
                                    // MoveIn m_SecondaryButton1
                                    m_SecondaryButton1.MoveIn(GSui.eGUIMove.SelfAndChildren);
                                }
                                else
                                {
                                    // MoveOut m_SecondaryButton1
                                    m_SecondaryButton1.MoveOut(GSui.eGUIMove.SelfAndChildren);
                                }
                            }
	
                            // Toggle m_Button2
                            function ToggleButton_2 () {
                                m_Button2_IsOn = !m_Button2_IsOn;
                                if(m_Button2_IsOn==true)
                                {
                                    // MoveIn m_SecondaryButton2
                                    m_SecondaryButton2.MoveIn(GSui.eGUIMove.SelfAndChildren);
                                }
                                else
                                {
                                    // MoveOut m_SecondaryButton2
                                    m_SecondaryButton2.MoveOut(GSui.eGUIMove.SelfAndChildren);
                                }
                            }
	
                            // Toggle m_Button3
                            function ToggleButton_3 () {
                                m_Button3_IsOn = !m_Button3_IsOn;
                                if(m_Button3_IsOn==true)
                                {
                                    // MoveIn m_SecondaryButton3
                                    m_SecondaryButton3.MoveIn(GSui.eGUIMove.SelfAndChildren);
                                }
                                else
                                {
                                    // MoveOut m_SecondaryButton3
                                    m_SecondaryButton3.MoveOut(GSui.eGUIMove.SelfAndChildren);
                                }
                            }
	
                            // Toggle m_Button4
                            function ToggleButton_4 () {
                                m_Button4_IsOn = !m_Button4_IsOn;
                                if(m_Button4_IsOn==true)
                                {
                                    // MoveIn m_SecondaryButton4
                                    m_SecondaryButton4.MoveIn(GSui.eGUIMove.SelfAndChildren);
                                }
                                else
                                {
                                    // MoveOut m_SecondaryButton4
                                    m_SecondaryButton4.MoveOut(GSui.eGUIMove.SelfAndChildren);
                                }
                            }
	
                            // Toggle m_Button5
                            function ToggleButton_5 () {
                                m_Button5_IsOn = !m_Button5_IsOn;
                                if(m_Button5_IsOn==true)
                                {
                                    // MoveIn m_SecondaryButton5
                                    m_SecondaryButton5.MoveIn(GSui.eGUIMove.SelfAndChildren);
                                }
                                else
                                {
                                    // MoveOut m_SecondaryButton5
                                    m_SecondaryButton5.MoveOut(GSui.eGUIMove.SelfAndChildren);
                                }
                            }
                        }
